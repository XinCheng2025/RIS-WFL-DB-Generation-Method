
function [Cluster1Map,Cluster2Map] = getClusterMap(p_T,p_I,dim,z_Rx,e_n,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_cs)
% A function of generating cluster maps for the SB-NLoS path and DB-NLoS path

Ncs_c=(x_Rx_u-x_Rx_l)/d_sc_cs;
Ncs_r=(y_Rx_u-y_Rx_l)/d_sc_cs;


C1_V=cell(Ncs_r,Ncs_c);C2_V=cell(Ncs_r,Ncs_c);
S1_V=cell(Ncs_r,Ncs_c);S2_V=cell(Ncs_r,Ncs_c);
p_c_1_V=cell(Ncs_r,Ncs_c);p_c_2_V=cell(Ncs_r,Ncs_c);
p_c_s_1_V=cell(Ncs_r,Ncs_c);p_c_s_2_V=cell(Ncs_r,Ncs_c);
belta_c_s_1_V=cell(Ncs_r,Ncs_c);belta_c_s_2_V=cell(Ncs_r,Ncs_c);

nlos_c=0;

for x=x_Rx_l+d_sc_cs/2:d_sc_cs:x_Rx_u-d_sc_cs/2
    nlos_c=nlos_c+1;nlos_r=0;
    for y=y_Rx_l+d_sc_cs/2:d_sc_cs:y_Rx_u-d_sc_cs/2
        nlos_r=nlos_r+1;
        [C1,S1,p_c_1,p_c_s_1,belta_c_s_1]=Cluster_Scatter_SB(p_T,x,y,z_Rx,dim);
        [C2,S2,p_c_2,p_c_s_2,belta_c_s_2]=Cluster_Scatter_DB(e_n,x,y,z_Rx,p_I,dim);
        C1_V{nlos_r,nlos_c}=C1;C2_V{nlos_r,nlos_c}=C2;
        S1_V{nlos_r,nlos_c}=S1;S2_V{nlos_r,nlos_c}=S2;
        p_c_1_V{nlos_r,nlos_c}=p_c_1;p_c_2_V{nlos_r,nlos_c}=p_c_2;
        p_c_s_1_V{nlos_r,nlos_c}=p_c_s_1;p_c_s_2_V{nlos_r,nlos_c}=p_c_s_2;
        belta_c_s_1_V{nlos_r,nlos_c}=belta_c_s_1;belta_c_s_2_V{nlos_r,nlos_c}=belta_c_s_2;
    end
end


Cluster1Map=struct();Cluster2Map=struct();
Cluster1Map.C1_V=C1_V;Cluster2Map.C2_V=C2_V;
Cluster1Map.S1_V=S1_V;Cluster2Map.S2_V=S2_V;
Cluster1Map.p_c_1_V=p_c_1_V;Cluster2Map.p_c_2_V=p_c_2_V;
Cluster1Map.p_c_s_1_V=p_c_s_1_V;Cluster2Map.p_c_s_2_V=p_c_s_2_V;
Cluster1Map.belta_c_s_1_V=belta_c_s_1_V;Cluster2Map.belta_c_s_2_V=belta_c_s_2_V;


end


