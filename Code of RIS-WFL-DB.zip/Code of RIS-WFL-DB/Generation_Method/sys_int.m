function [Para, Para_M, Para_T, Para_R, Para_I ]=sys_int()
%A function for generating basic parameters
%Para:    Environment structure
%Para_M:  Measurement structure
%Para_T:  Tx  structure
%Para_R:  Rx  structure
%Para_I:   RIS  structure

%% Environment  parameters
dim=[20,20,3.5];  % The size of indoor environment
frequency=5.2;     % frequency (GHz)
lambda=3*10^8/(frequency*10^9); % wavelength
n_LOS=1.73;           % Path loss exponent (LOS)
sigma_LOS=3.02;       % SF term (dB) (LOS)
n_NLOS=3.19;          % Path loss exponent (NLOS)
sigma_NLOS=8.29;      % SF term (dB) (NLOS)
s_Tx=1;               % Plot signal

%% Parameters about Tx, Rx, RIS
d_T=lambda/2;
M_T=4;
M_I=20;N_I=20;I=M_I*N_I;
A=1;
d_I_x=lambda/2; d_I_y=lambda/2;
p_T=[0;10;3];
p_I=[10;15;3];
e_T=[0;0;-1];e_T_n=[1;0;0];   %orientation of Tx
e_r=[0;0;1];e_c=[1;0;0];e_n=[0;-1;0];   %orientation of RIS
e_R_n=[0;0;1];      %orientation of Rx
P_0_dBm=10;
P_0=10.^(P_0_dBm./10);
G_T_max=10.^(8./10); %Tx is equipped with a directioanl antenna
G_R_max=10.^(0/10);  %Rx is equipped with omnidirectional antenna
G_I_max=4*pi*d_I_x*d_I_y/(lambda^2);  %Max gain of reflective unit

MC_vector=[0.606+0.308*1i,-0.234+0.614*1i,0.0375-0.324*1i]; %MC vector
MC_norm=0.3; % norm of MC vector 
MC_Index=0;  % switch index of MC 
%% measurement parameter

%Area of interesting (AoI) of the position sensing serverce
x_Rx_l=5;x_Rx_u=15;
y_Rx_l=0;y_Rx_u=10;

% surveying grid
delta_survey_x=0.2;
delta_survey_y=0.2;

z_Rx=1;% Rx hegight
Nsur=(x_Rx_u-x_Rx_l)/delta_survey_x*(y_Rx_u-y_Rx_l)/delta_survey_y;
Rx_xyz_survey=zeros(Nsur,3);
ns=0;
for x_Rx=x_Rx_l+delta_survey_x/2:delta_survey_x:x_Rx_u-delta_survey_x/2
    for y_Rx=y_Rx_l+delta_survey_y/2:delta_survey_y:y_Rx_u-delta_survey_y/2
        ns=ns+1;
        Rx_xyz_survey(ns,:)=[x_Rx, y_Rx, z_Rx]; %surveying positions
    end
end
Nmeasure=20;          % Number of Measurements at each surveing position

% beamforming strategy of Tx and phase shift strategy of RIS
f=make_f(Nmeasure,M_T);
Phi=make_Phi(lambda,Nmeasure,x_Rx_l,x_Rx_u,y_Rx_l,y_Rx_u,N_I,M_I,e_c,e_r,d_I_x,d_I_y,I,z_Rx,p_I,p_T);

%% Generate cluster map
d_sc_cs=2.5;% The coherence distance of cluster
[Cluster1Map,Cluster2Map]=getClusterMap(p_T,p_I,dim,z_Rx,e_n,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_cs);
%Cluster1Map: Cluster map for the SB-NLoS path
%Cluster2Map: Cluster map for the DB-NLoS path


%% Generate LoS/VLoS condition map
d_sc_los=1;d_sc_vlos=1; % The coherence distance of LoS/VLoS condition
d_co_los=2;d_co_vlos =2; % The correlation distance of LoS/VLoS condition
LosMap=getLosMap(p_T,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_los,d_co_los);
VLosMap=getVLosMap(p_I,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_vlos,d_co_vlos);


%% Generate SF term maps
d_sc_sf=1; % The coherence distance of SF
d_co_sF=4; % The correlation distance of SF
sfMap_LoS = getSFMap_LoS(sigma_LOS,d_sc_sf,d_co_sF,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l);
sfMap_NLoS = getSFMap_NLoS(sigma_NLOS,d_sc_sf,d_co_sF,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l);


%% Generate the site survey index from the map index
Index_cs=zeros(Nsur,2);Index_los=zeros(Nsur,2);Index_vlos=zeros(Nsur,2);Index_sf=zeros(Nsur,2);
ns=0;
for x_Rx=x_Rx_l+delta_survey_x/2:delta_survey_x:x_Rx_u-delta_survey_x/2
    for y_Rx=y_Rx_l+delta_survey_y/2:delta_survey_y:y_Rx_u-delta_survey_y/2
        ns=ns+1;
        Index_cs_1=max(ceil((x_Rx-x_Rx_l-delta_survey_x/2)/d_sc_cs),1);
        Index_cs_2=max(ceil((y_Rx-y_Rx_l-delta_survey_y/2)/d_sc_cs),1);
        Index_cs(ns,:)=[Index_cs_1,Index_cs_2];
        Index_los_1=max(ceil((x_Rx-x_Rx_l-delta_survey_x/2)/d_sc_los),1);
        Index_los_2=max(ceil((y_Rx-y_Rx_l-delta_survey_y/2)/d_sc_los),1);
        Index_los(ns,:)=[Index_los_1,Index_los_2];
        Index_vlos_1=max(ceil((x_Rx-x_Rx_l-delta_survey_x/2)/d_sc_vlos),1);
        Index_vlos_2=max(ceil((y_Rx-y_Rx_l-delta_survey_y/2)/d_sc_vlos),1);
        Index_vlos(ns,:)=[Index_vlos_1,Index_vlos_2];
        Index_sf_1=max(ceil((x_Rx-x_Rx_l-delta_survey_x/2)/d_sc_sf),1);
        Index_sf_2=max(ceil((y_Rx-y_Rx_l-delta_survey_y/2)/d_sc_sf),1);
        Index_sf(ns,:)=[Index_sf_1,Index_sf_2];
    end
end


%% Assign the parameters to the structures
Para = struct();Para_M=struct();Para_T= struct();Para_I= struct();Para_R=struct();

Para.dim =dim;
Para.frequency = frequency;
Para.lambda =lambda;
Para.P_0 =P_0;
Para.n_NLOS = n_NLOS;
Para.sigma_NLOS = sigma_NLOS;
Para.n_LOS = n_LOS;
Para.sigma_LOS = sigma_LOS;
Para.d_sc_cs = d_sc_cs;
Para.Cluster1Map=Cluster1Map;
Para.Cluster2Map=Cluster2Map;
Para.LosMap=LosMap;Para.VLosMap=VLosMap;
Para.sfMap_LoS=sfMap_LoS;
Para.sfMap_NLoS=sfMap_NLoS;
Para.MC_Index=MC_Index;


Para_M.Nmeasure = Nmeasure;
Para_M.Nsur = Nsur;
Para_M.Rx_xyz_survey =Rx_xyz_survey;
Para_M.x_Rx_l = x_Rx_l;
Para_M.x_Rx_u = x_Rx_u;
Para_M.y_Rx_l = y_Rx_l;
Para_M.y_Rx_u = y_Rx_u;
Para_M.delta_survey_x = delta_survey_x;
Para_M.delta_survey_y = delta_survey_y;
Para_M.Phi=Phi;
Para_M.f=f;
Para_M.s_Tx=s_Tx;
Para_M.Index_cs=Index_cs;
Para_M.Index_los=Index_los;
Para_M.Index_vlos=Index_vlos;
Para_M.Index_sf=Index_sf;

Para_T.d_T = d_T;
Para_T.M_T = M_T;
Para_T.p_T = p_T;
Para_T.e_T = e_T;
Para_T.e_T_n = e_T_n;
Para_T.G_T_max=G_T_max;

Para_I.M_I = M_I;
Para_I.N_I = N_I;
Para_I.I = I;
Para_I.A=A;
Para_I.d_I_x = d_I_x;
Para_I.d_I_y = d_I_y;
Para_I.p_I = p_I;
Para_I.e_c = e_c;
Para_I.e_r = e_r;
Para_I.e_n = e_n;
Para_I.G_I_max=G_I_max;
Para_I.MC_vector=MC_vector;
Para_I.MC_norm=MC_norm;

Para_R.z_Rx = z_Rx;
Para_R.e_R_n = e_R_n;
Para_R.G_R_max=G_R_max;

end


