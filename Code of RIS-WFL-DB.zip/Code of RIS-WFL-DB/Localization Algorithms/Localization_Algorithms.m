clear all;

%% Read data
filename = sprintf('RIS-WFL-DB.xlsx'); %read excel file, the file path should be added
% Load data from the excel file
data = readtable(filename);
% Split the data into input (RSS features) and output (coordinates X, Y)
X = data{:, 1:end-3}; % RSS values (features)
y = data{:, end-2:end-1}; % Coordinates (X, Y)

%% Settins

Re=3;% number of randomizations
Split_ratio=0.2; %split ratio
Select_index=[1 2 3 4]; %1:CNN;2:GP;3:DNN;4:KNN
 

%% Definitions
Size_test_data=size(X,1)*Split_ratio;
Errors_CNN=zeros(Re,Size_test_data);RSME_CNN=zeros(Re,1);
Errors_GP=zeros(Re,Size_test_data);RSME_GP=zeros(Re,1);
Errors_DNN=zeros(Re,Size_test_data);RSME_DNN=zeros(Re,1);
Errors_KNN=zeros(Re,Size_test_data);RSME_KNN=zeros(Re,1);



%% Algorithms
for re=1:Re
    % Split the data into training and testing sets (80% train, 20% test)
    seed=randi([0, 100]); %random seed
    rng(seed); 
    cv=cvpartition(size(X, 1), 'HoldOut', 0.2);
    X_train= X(training(cv), :);
    Y_train= y(training(cv),:);
    X_test= X(test(cv), :);
    Y_test= y(test(cv), :);
    
    
    %% 1D-CNN
    if ismember(1, Select_index)
        Input_size=size(X_train,2);
        X_train_CNN=zeros(size(X_train, 2),1,1,size(X_train, 1));
        X_test_CNN=zeros(size(X_test, 2),1,1,size(X_test, 1));
        for i=1:size(X_train, 2)
            for j=1:size(X_train, 1)
                X_train_CNN(i,1,1,j)=X_train(j,i);
            end
        end
        for i=1:size(X_test, 2)
            for j=1:size(X_test, 1)
                X_test_CNN(i,1,1,j)=X_test(j,i);
            end
        end
        
        layers = [
            imageInputLayer([Input_size, 1, 1], 'Name', 'input', 'Normalization', 'none')
            convolution2dLayer([4, 1], 32, 'Padding', 'same', 'Name', 'conv1')
            batchNormalizationLayer('Name', 'batchnorm1')
            reluLayer('Name', 'relu1')
            
            convolution2dLayer([4, 1], 64, 'Padding', 'same', 'Name', 'conv2')
            batchNormalizationLayer('Name', 'batchnorm2')
            reluLayer('Name', 'relu2')
            
            fullyConnectedLayer(256, 'Name', 'fc1')
            reluLayer('Name', 'relu_fc1')
            fullyConnectedLayer(64, 'Name', 'fc2')
            reluLayer('Name', 'relu_fc2')
            fullyConnectedLayer(2, 'Name', 'fc3')
            regressionLayer('Name', 'output')
            ];
        Max_epoch=500;
        options = trainingOptions('adam', 'MaxEpochs', Max_epoch, 'Verbose', false);
        [net_CNN,tr_CNN] = trainNetwork(X_train_CNN, Y_train, layers, options);
        y_pred_cnn = net_CNN.predict(X_test_CNN);
        Errors_CNN(re,:)=sqrt(sum((y_pred_cnn - Y_test).^2,2)).';
        RSME_CNN(re)=sqrt(mean(sum((y_pred_cnn-Y_test).^2, 2)));
    end
    
    %% GP
    if ismember(2, Select_index)
        sigma = 50;
        
        theta = gaussianKernelRegression(X_train, Y_train, sigma);
        y_pred_gp=predictGaussianKernel(X_train, X_test, theta, sigma);
        Errors_GP(re,:)=sqrt(sum((y_pred_gp-Y_test).^2,2)).';
        RSME_GP(re)=sqrt(mean(sum((y_pred_gp-Y_test).^2, 2)));
    end
    
    %% DNN
    if ismember(3, Select_index)
        dnn = fitnet([256 128 32]);
        dnn.layers{1}.transferFcn = 'tansig';
        dnn.layers{2}.transferFcn = 'tansig';
        dnn.layers{3}.transferFcn = 'tansig';
        dnn.layers{4}.transferFcn = 'purelin';
        dnn.trainFcn = 'trainscg';
        dnn.trainParam.max_fail = Max_epoch-1;
        dnn.trainParam.epochs = Max_epoch-1;
        [dnn,tr] = train(dnn, X_train.', Y_train.');
        y_pred_dnn=dnn(X_test.').';
        Errors_DNN(re,:)=sqrt(sum((y_pred_dnn-Y_test).^2,2)).';
        RSME_DNN(re)=sqrt(mean(sum((y_pred_dnn-Y_test).^2, 2)));
    end
    %% KNN
    if ismember(4, Select_index)
        k=2;
        [y_pred_knn]=knn_predict(X_train, Y_train, X_test, k);
        Errors_KNN(re,:)=sqrt(sum((y_pred_knn-Y_test).^2,2));
        RSME_KNN(re)=sqrt(mean(sum((y_pred_knn-Y_test).^2, 2)));
    end
    
end

%% Final results
Errors_CNN_ave=squeeze(mean(Errors_CNN,1));  RSME_CNN_ave=mean(RSME_CNN);
Errors_GP_ave=squeeze(mean(Errors_GP,1));    RSME_GP_ave=mean(RSME_GP);
Errors_DNN_ave=squeeze(mean(Errors_DNN,1));  RSME_DNN_ave=mean(RSME_DNN);
Errors_KNN_ave=squeeze(mean(Errors_KNN,1));  RSME_KNN_ave=mean(RSME_KNN);


%% auxiliary functions
function dist = euclidean_distance(a, b)
dist = sqrt(sum((a - b).^2));
end

function [y_pred_knn] = knn_predict(X_train, Y_train, X_test, k)
y_pred_knn = zeros(size(X_test, 1), 2);
for i = 1:size(X_test, 1)
    distances = zeros(size(X_train, 1), 1);
    for j = 1:size(X_train, 1)
        distances(j) = euclidean_distance(X_test(i,:), X_train(j,:));
    end
    
    [~, sorted_indices] = sort(distances);
    nearest_neighbors = sorted_indices(1:k);
    
    nearest_labels = Y_train(nearest_neighbors, :);
    
    y_pred_knn(i, :) = mean(nearest_labels, 1);
end
end

function K = gaussianKernel(X1, X2, sigma)
sqDist = pdist2(X1, X2, 'euclidean').^2;
K = exp(-sqDist / (2 * sigma^2));
end

function [theta] = gaussianKernelRegression(X_train, Y_train, sigma)
K = gaussianKernel(X_train, X_train, sigma);
lambda = 1e-3;
I = eye(size(K, 1));
theta = (K + lambda * I) \ Y_train;
end

function Y_pred = predictGaussianKernel(X_train, X_test, theta, sigma)
K_test = gaussianKernel(X_test, X_train, sigma);
Y_pred = K_test * theta;
end



