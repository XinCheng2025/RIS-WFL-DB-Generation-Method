
function LosMap = getLosMap(p_T,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_los,d_co_los)

% A function of generating LoS condition map

Nlos_c=(x_Rx_u-x_Rx_l)/d_sc_los;
Nlos_r=(y_Rx_u-y_Rx_l)/d_sc_los;
d_2D=zeros(Nlos_r,Nlos_c);Pr_LOS=zeros(Nlos_r,Nlos_c);
nlos_c=0;
for x=x_Rx_l+d_sc_los/2:d_sc_los:x_Rx_u-d_sc_los/2
    nlos_c=nlos_c+1;nlos_r=0;
    for y=y_Rx_l+d_sc_los/2:d_sc_los:y_Rx_u-d_sc_los/2
        nlos_r=nlos_r+1;
        d_2D(nlos_r,nlos_c)=norm([x;y]-[p_T(1);p_T(2)],2);
        
        if  d_2D<=1.2
            Pr_LOS(nlos_r,nlos_c) =1;
        elseif  1.2<d_2D<6.5
            Pr_LOS(nlos_r,nlos_c) =exp((-d_2D(nlos_r,nlos_c)-1.2)/4.7);
        elseif d>=6.5
            Pr_LOS(nlos_r,nlos_c) =exp((-d_2D(nlos_r,nlos_c)-6.5)/32.6)*0.32;
        end
    end
end

if Nlos_c==Nlos_r
    N_LoS=Nlos_c;
end

delta = d_co_los/d_sc_los;
M = floor(8*delta+1);
if mod(M,2) == 0
    M = M-1;
end
h = zeros(M);
InitMap = randn(N_LoS+M-1);


for i = 1:M
    for j = 1:M
        h(i,j) = exp(-sqrt(((M+1)/2-i).^2+((M+1)/2-j).^2)/d_co_los);
    end
end

CorrMapPad = conv2(InitMap,h,'same');
CorrQ = CorrMapPad((M+1)/2:(M+1)/2+N_LoS-1,(M+1)/2:(M+1)/2+N_LoS-1);
CorrK = 1/2*(1+erf(CorrQ/sqrt(2)));
LosMap = double(CorrK < Pr_LOS);


end


