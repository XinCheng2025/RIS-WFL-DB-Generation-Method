function Phi = make_Phi(lambda,Nmeasure,x_Rx_l,x_Rx_u,y_Rx_l,y_Rx_u,N_I,M_I,e_c,e_r,d_I_x,d_I_y,I,z_Rx,p_I,p_T)
% A function of generating phase shift strategy of RIS 

[M_A,N_A]=RowandColumn(Nmeasure);
k=2*pi/lambda;     % Wavenumber
p_R_V=zeros(Nmeasure,3);

for n=1:Nmeasure
    n_c=mod(n-1,N_A)+1;n_r=floor((n-1)/N_A)+1;
    x=x_Rx_l+(x_Rx_u-x_Rx_l)/(N_A*2)+n_c*(x_Rx_u-x_Rx_l)/N_A;
    y=y_Rx_l+(y_Rx_u-y_Rx_l)/(M_A*2)+n_r*(y_Rx_u-y_Rx_l)/M_A;
    p_R_V(n,:)=[x,y, z_Rx];
end
A_I=zeros(I,3);
for i=1:I
    m_i=floor((i-1)/N_I)+1;n_i=mod(i-1,N_I)+1;
    A_I(i,:)=(m_i-(M_I+1)/2)*d_I_y*e_c+(n_i-(N_I+1)/2)*d_I_x*e_r;
end
Phi=zeros(Nmeasure,I,I);
for n=1:Nmeasure
    p_R=p_R_V(n,:);
    d_I_T=zeros(I,1);d_I_R=zeros(I,1);
    for i=1:I
        d_I_T(i,1)=norm(p_I-p_T+A_I(i,:),2);
        d_I_R(i,1)=norm(p_R-p_I-A_I(i,:),2);
    end
    for i=1:I
        Phi(n,i,i)=exp(1i*k*(d_I_T(i,1)+d_I_R(i,1)));
    end
end

end

function [M_A, N_A] = RowandColumn(Nmeasure)
min_diff = inf;  % 初始化最小差值
M_A = 0;  %行数
N_A= 0;   %列数
for i = 1:Nmeasure
    if mod(Nmeasure, i) == 0  
        temp_a = i;
        temp_b = Nmeasure/ i;
        diff = abs(temp_a - temp_b);
        if diff < min_diff
            M_A = temp_a;
            N_A = temp_b;
            min_diff = diff;
        end
    end
end
end


