function H = get_channel(ns,p_R,Phi,Para,Para_M, Para_T, Para_R, Para_I)


%% read parameters form structures
lambda=Para.lambda;
n_NLOS=Para.n_NLOS;
n_LOS = Para.n_LOS;
LosMap = Para.LosMap;
VLosMap= Para.VLosMap;
sfMap_LoS=Para.sfMap_LoS;
sfMap_NLoS=Para.sfMap_NLoS;
Cluster1Map=Para.Cluster1Map;
Cluster2Map=Para.Cluster2Map;

Index_cs=Para_M.Index_cs(ns,:);
Index_los=Para_M.Index_los(ns,:);
Index_vlos=Para_M.Index_vlos(ns,:);
Index_sf=Para_M.Index_sf(ns,:);

d_T=Para_T.d_T;
M_T=Para_T.M_T;
p_T=(Para_T.p_T).';
e_T=Para_T.e_T;
e_T_n=Para_T.e_T_n;
G_T_max=Para_T.G_T_max;

M_I=Para_I.M_I;
N_I=Para_I.N_I;
I=Para_I.I;
A=Para_I.A;
d_I_x=Para_I.d_I_x;
d_I_y=Para_I.d_I_y;
p_I=(Para_I.p_I).';
e_c=Para_I.e_c;
e_r=Para_I.e_r;
e_n=Para_I.e_n;
G_I_max=Para_I.G_I_max;

e_R_n=Para_R.e_R_n;
G_R_max=Para_R.G_R_max;

C1=Cluster1Map.C1_V{Index_cs};
C2=Cluster2Map.C2_V{Index_cs};
S1=Cluster1Map.S1_V{Index_cs};
S2=Cluster2Map.S2_V{Index_cs};
p_c_1=Cluster1Map.p_c_1_V{Index_cs};
p_c_2=Cluster2Map.p_c_2_V{Index_cs};
belta_c_s_1=Cluster1Map.belta_c_s_1_V{Index_cs};
belta_c_s_2=Cluster2Map.belta_c_s_2_V{Index_cs};
p_c_s_1=Cluster1Map.p_c_s_1_V{Index_cs};
p_c_s_2=Cluster2Map.p_c_s_2_V{Index_cs};


%%  Calculate distance and angle parameters
A_T=zeros(M_T,3);
for m=1:M_T
    A_T(m,:)=(m-(M_T+1)/2)*d_T*e_T;
end
A_I=zeros(I,3);
for i=1:I
    m_i=floor((i-1)/N_I)+1;n_i=mod(i-1,N_I)+1;
    A_I(i,:)=(m_i-(M_I+1)/2)*d_I_y*e_c+(n_i-(N_I+1)/2)*d_I_x*e_r;
end

d_TR=norm(p_R-p_T,2);
d_TI=norm(p_I-p_T,2);
d_IR=norm(p_R-p_I,2);

d_TC_1=zeros(C1,1);d_CR_1=zeros(C1,1);
for c1=1:C1
    d_TC_1(c1)=norm(p_c_1(c1,:)-p_T,2);
    d_CR_1(c1)=norm(p_R-p_c_1(c1,:),2);
end
d_IC_2=zeros(C2,1);d_CR_2=zeros(C2,1);
for c2=1:C2
    d_IC_2(c2)=norm(p_c_2(c2,:)-p_I,2);
    d_CR_2(c2)=norm(p_R-p_c_2(c2,:),2);
end

d_TR_m=zeros(M_T,1);d_TC_1_m_c=zeros(M_T,C1);d_TC_1_m_c_s=zeros(M_T,sum(S1));d_TI_m_i=zeros(M_T,I);
for m=1:M_T
    d_TR_m(m,1)=norm(p_R-p_T-A_T(m,:),2);
    s=0;
    for c1=1:C1
        d_TC_1_m_c(m,c1)=norm(p_c_1(c1,:)-p_T-A_T(m,:),2);
        for s1=1:S1(c1)
            s=s+1;
            d_TC_1_m_c_s(m,s)=norm(p_c_s_1(s,:)-p_T-A_T(m,:),2);
        end
    end
    for i=1:I
        d_TI_m_i(m,i)=norm(p_I-p_T- A_T(m,:)+A_I(i,:),2);
    end
end

d_IR_i=zeros(I,1);d_IC_2_i_c=zeros(I,C2);d_IC_2_i_c_s=zeros(I,sum(S2));
for i=1:I
    d_IR_i(i,1)=norm(p_R-p_I-A_I(i,:),2);
    s=0;
    for c2=1:C2
        d_IC_2_i_c(i,c2)=norm(p_c_2(c2,:)-p_I-A_I(i,:),2);
        for s2=1:S2(c2)
            s=s+1;
            d_IC_2_i_c_s(i,s)=norm(p_c_s_2(s,:)-p_I-A_I(i,:),2);
        end
    end
end

d_CR_1_c=zeros(C1,1);d_CR_2_c=zeros(C2,1);d_CR_1_c_s=zeros(sum(S1),1);d_CR_2_c_s=zeros(sum(S2),1);
s=0;
for c1=1:C1
    d_CR_1_c(c1,1)=norm(p_R-p_c_1(c1,:),2);
    for s1=1:S1(c1)
        s=s+1;
        d_CR_1_c_s(s,1)=norm(p_R-p_c_s_1(s,:),2);
    end
end

s=0;
for c2=1:C2
    d_CR_2_c(c2,1)=norm(p_R-p_c_2(c2,:),2);
    for s2=1:S2(c2)
        s=s+1;
        d_CR_2_c_s(s,1)=norm(p_R-p_c_s_2(s,:),2);
    end
end

s_C2_S=sum(S2);


phi_TR=acos((p_R-p_T)*e_T_n/(d_TR));
phi_TI=acos((p_I-p_T)*e_T_n/(d_TI));
phi_TC_1=zeros(C1,1);
for c1=1:C1
    phi_TC_1(c1)=acos((p_c_1(c1,:)-p_T)*e_T_n/(d_TC_1(c1)));
end
phi_IT=acos((p_T-p_I)*e_n/(d_TI));
phi_IR=acos((p_R-p_I)*e_n/(d_IR));
phi_IC_2=zeros(C2,1);
for c2=1:C2
    phi_IC_2(c2)=acos((p_c_2(c2,:)-p_I)*e_n/(d_IC_2(c2)));
end
phi_RC_1=zeros(C1,1);
phi_RC_2=zeros(C2,1);
phi_RT=acos((p_T-p_R)*e_R_n/(d_TR));
phi_RI=acos((p_I-p_R)*e_R_n/(d_IR));
for c1=1:C1
    phi_RC_1(c1)=acos((p_c_1(c1,:)-p_R)*e_R_n/(d_CR_1(c1)));
end
for c2=1:C2
    phi_RC_2(c2)=acos((p_c_2(c2,:)-p_R)*e_R_n/(d_CR_2(c2)));
end

%%  Calculate path loss
d_0=1;
PL_LoS=20*log10(4 *pi*d_0/lambda)+10*n_LOS*log10(d_TR/d_0)+sfMap_LoS(Index_sf(1),Index_sf(2));
L_LoS=10^(-PL_LoS/10);

d_0_1=1;d_0_2=1;
PL_VLoS =20*log10((4*pi*d_0_1*d_0_2)/(I*d_I_x*d_I_y*A)) ...
    +10*n_LOS*log10((d_TI*d_IR)/(d_0_1*d_0_2))+sfMap_LoS(Index_sf(1),Index_sf(2));
L_VLoS=10^(-PL_VLoS/10);

L_SB_NLoS=zeros(C1,1);
for c1=1:C1
    PL_SB_NLoS=20*log10(4 *pi*d_0/lambda)+10 *n_NLOS*log10((d_TC_1(c1)+d_CR_1(c1))/d_0)+sfMap_NLoS(Index_sf(1),Index_sf(2));
    L_SB_NLoS(c1,1)=10^(-PL_SB_NLoS/10);
end

L_DB_NLoS=zeros(C2,1);
for c2=1:C2
    PL_DB_NLoS=20*log10((4*pi*d_0_1*d_0_2)/(I*d_I_x*d_I_y*A))+10 *n_NLOS*log10(d_TI*(d_IC_2(c2)+d_CR_2(c2))/(d_0_1*d_0_2))+sfMap_NLoS(Index_sf(1),Index_sf(2));
    L_DB_NLoS(c2,1)=10^(-PL_DB_NLoS/10);
end

%%  Calculate radiation pattern
G_T = @(phi) (G_T_max*(cos(phi)^(G_T_max/2-1)));
G_I = @(phi_1,phi_2) (G_I_max*cos(phi_1)*cos(phi_2));
G_R = @(phi) (G_R_max);


%%  Calculate channel
H=zeros(1,M_T);
for m=1:M_T
    h_LoS_m=sqrt(L_LoS *G_T(phi_TR)*G_R(phi_RT))*exp(-1j*2*pi*d_TR_m(m)/lambda);
    
    if Para.MC_Index==0
        phase_m=zeros(I,1);
        for i = 1:I
            phase_m(i,1)=exp(1j *(Phi(i,i)-2*pi*(d_TI_m_i(m,i)+d_IR_i(i))/lambda));
        end
        h_VLoS_m=sqrt(L_VLoS*G_T(phi_TI)*G_R(phi_RI)*G_I(phi_IT,phi_IR))*sum(phase_m);
    elseif Para.MC_Index==1
        a_IR=zeros(I,1);a_TI_m=zeros(I,1);
        for i = 1:I
            a_TI_m(i,1)=exp(1j *(-2*pi*d_TI_m_i(m,i)/lambda));
            a_IR(i,1)=exp(1j *(-2*pi*d_IR_i(i)/lambda));
        end
        phase_m_sum=a_TI_m.'*Phi*a_IR;
        h_VLoS_m=sqrt(L_VLoS*G_T(phi_TI)*G_R(phi_RI)*G_I(phi_IT,phi_IR))*phase_m_sum;
    end
    
    s=0;h=0;
    for c1=1:C1
        for s1=1:S1(c1)
            s=s+1;
            h=h+belta_c_s_1(s)*sqrt(L_SB_NLoS(c1)*G_T(phi_TC_1(c1))*G_R(phi_RC_1(c1)))*exp(1j *(-2*pi*(d_TC_1_m_c_s(m,s) +d_CR_1_c_s(s,1))/lambda));
        end
    end
    h_SB_NLoS_m=h;
    
    if Para.MC_Index==0
        s=0;h=0;
        for c2=1:C2
            for s2=1:S2(c2)
                s=s+1;
                for i = 1:I
                    phase_m(i,1)=exp(1j *(Phi(i,i)-2*pi*(d_TI_m_i(m,i) +d_IC_2_i_c_s(i,s)+d_CR_2_c_s(s,1))/lambda));
                end
                h=h+belta_c_s_2(s)*sqrt(L_DB_NLoS(c2)*G_T(phi_TI)*G_R(phi_RC_2(c2))*G_I(phi_IT,phi_IC_2(c2)))*sum(phase_m);
            end
        end
    elseif Para.MC_Index==1
        a_ICR_c_s=zeros(I,s_C2_S);
        for s=1:s_C2_S
            for i = 1:I
                a_ICR_c_s(i,s)=exp(1j *(-2*pi*(d_IC_2_i_c_s(i,s)+d_CR_2_c_s(s,1))/lambda));
            end
        end
        s=0;h=0;
        for c2=1:C2
            for s2=1:S2(c2)
                s=s+1;
                phase_m_sum=a_TI_m.'*Phi*a_ICR_c_s(:,s);
                h=h+belta_c_s_2(s)*sqrt(L_DB_NLoS(c2)*G_T(phi_TI)*G_R(phi_RC_2(c2))*G_I(phi_IT,phi_IC_2(c2)))*phase_m_sum;
            end
        end
    end
    h_DB_NLoS_m=h;

    H(m)= LosMap(Index_los(1),Index_los(2))* h_LoS_m+VLosMap(Index_vlos(1),Index_vlos(2))*h_VLoS_m+h_SB_NLoS_m+h_DB_NLoS_m;
end


end



