function MC_M=make_MC(Para_T,Para_M,Para,Para_I,Para_R)

I=Para_I.I;
MC_vector=Para_I.MC_vector;
MC_norm=Para_I.MC_norm;
MC_value=MC_norm*MC_vector;
M_r=sqrt(I);


A_0_0=eye(M_r);
A_1_0=diag(ones(1, M_r-1), 1)+diag(ones(1, M_r-1), -1);
A_2_0=zeros(M_r);
A_0_1=zeros(M_r);
A_1_1=eye(M_r);
A_2_1=diag(ones(1, M_r-1), 1)+diag(ones(1, M_r-1), -1);
A_0_2=zeros(M_r);
A_1_2=zeros(M_r);
A_2_2=zeros(M_r); 
A_Others=zeros(M_r);


A_0=A_0_0*MC_value(1)+A_1_0*MC_value(2)+A_2_0*MC_value(3);
A_1=A_0_1*MC_value(1)+A_1_1*MC_value(2)+A_2_1*MC_value(3);
A_2=A_0_2*MC_value(1)+A_1_2*MC_value(2)+A_2_2*MC_value(3);


A=zeros(I);
for u=1:M_r
    for v=1:M_r
        if abs(u-v)==0
        A((u-1)*M_r+1:u*M_r,(v-1)*M_r+1:v*M_r)=A_0;
        elseif abs(u-v)==1
         A((u-1)*M_r+1:u*M_r,(v-1)*M_r+1:v*M_r)=A_1;
        elseif abs(u-v)==2  
            A((u-1)*M_r+1:u*M_r,(v-1)*M_r+1:v*M_r)=A_2;
        else
            A((u-1)*M_r+1:u*M_r,(v-1)*M_r+1:v*M_r)=A_Others;
        end
    end
end
    
MC_M=A;



end