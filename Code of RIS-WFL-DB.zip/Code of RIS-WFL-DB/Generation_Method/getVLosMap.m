
function VLosMap = getVLosMap(p_I,x_Rx_u,x_Rx_l,y_Rx_u,y_Rx_l,d_sc_vlos,d_co_vlos)

% A function of generating VLoS condition map

NVlos_c=(x_Rx_u-x_Rx_l)/d_sc_vlos;
NVlos_r=(y_Rx_u-y_Rx_l)/d_sc_vlos;
d_2D=zeros(NVlos_r,NVlos_c);Pr_VLOS=zeros(NVlos_r,NVlos_c);
nvlos_c=0;
for x=x_Rx_l+d_sc_vlos/2:d_sc_vlos:x_Rx_u-d_sc_vlos/2
        nvlos_c=nvlos_c+1;nvlos_r=0;
for y=y_Rx_l+d_sc_vlos/2:d_sc_vlos:y_Rx_u-d_sc_vlos/2
            nvlos_r=nvlos_r+1;
d_2D(nvlos_r,nvlos_c)=norm([x;y]-[p_I(1);p_I(2)],2);

if  d_2D<=2.4 
Pr_VLOS(nvlos_r,nvlos_c) =1;
elseif  2.4<d_2D<13
Pr_VLOS(nvlos_r,nvlos_c) =exp((-d_2D(nvlos_r,nvlos_c)-1.2)/4.7);
elseif d_2D>=13
Pr_VLOS(nvlos_r,nvlos_c) =exp((-d_2D(nvlos_r,nvlos_c)-6.5)/32.6)*0.32;
end
end
end

if NVlos_c==NVlos_r
    N_LoS=NVlos_c;
end

VLosMap=zeros(N_LoS,N_LoS);

while sum(VLosMap(:) == 0)>=N_LoS^2/2
delta = d_co_vlos/d_sc_vlos;
M = floor(8*delta+1);
if mod(M,2) == 0
    M = M-1;
end
h = zeros(M);
InitMap = randn(N_LoS+M-1);

for i = 1:M
    for j = 1:M
        h(i,j) = exp(-sqrt(((M+1)/2-i).^2+((M+1)/2-j).^2)/d_co_vlos);
    end
end
CorrMapPad = conv2(InitMap,h,'same');
CorrQ = CorrMapPad((M+1)/2:(M+1)/2+N_LoS-1,(M+1)/2:(M+1)/2+N_LoS-1);
CorrK = 1/2*(1+erf(CorrQ/sqrt(2)));
VLosMap = double(CorrK < Pr_VLOS);
end


end


