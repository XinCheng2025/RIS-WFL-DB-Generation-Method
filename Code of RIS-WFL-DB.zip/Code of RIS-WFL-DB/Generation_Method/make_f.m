function f = make_f(Nmeasure,M_T)
% A function of generating beamforming strategy of Tx

f=zeros(Nmeasure,M_T);
for n=1:Nmeasure
    for m=1:M_T
        f(n,m)=exp(1i*2*pi)/sqrt(M_T);
    end
end

end