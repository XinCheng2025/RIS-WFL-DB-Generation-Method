clear all;

%The main procedure of generating RIS-assisted fingerprint database

%% Get and read  parameters
[Para, Para_M, Para_T, Para_R, Para_I]=sys_int();
 
P_0=Para.P_0;
Nsur=Para_M.Nsur;
Phi=Para_M.Phi;
f=Para_M.f;
s_Tx=Para_M.s_Tx;
Rx_xyz_survey=Para_M.Rx_xyz_survey;
Nmeasure=Para_M.Nmeasure;  
I=Para_I.I;


%% Generate the fingerprint database  
RSS=zeros(Nsur,Nmeasure);
fingerprint_database=zeros(Nsur,Nmeasure+3);
for ns=1:Nsur
    for n=1:Nmeasure
        p_R=Rx_xyz_survey(ns,:);
        Phi_n=reshape(Phi(n,:,:),I,I);
        H=get_channel(ns,p_R,Phi_n,Para, Para_M, Para_T, Para_R, Para_I);
        RSS(ns,n)=10*log10(abs(sqrt(P_0)*H*(f(n,:).')*s_Tx)^2);
    end
    fingerprint_database(ns,:)=[RSS(ns,:), p_R(1), p_R(2), p_R(3)];
end


%% Save the generated fingerprint database and basic parameters

% Save fingerprint databae to Excel
headers = cell(1, Nmeasure + 3); 
for i = 1:Nmeasure
    headers{i} = ['RSS', num2str(i)];
end
headers{Nmeasure + 1} = 'X';
headers{Nmeasure + 2} = 'Y';
headers{Nmeasure + 3} = 'Z';
filename = sprintf('fingerprint_database.xlsx');
xlswrite(filename, headers, 'Sheet1', 'A1');
xlswrite(filename, fingerprint_database, 'Sheet1', 'A2');


% Save basic parameters
save('Para.mat','Para');
save('Para_M.mat','Para_M');
save('Para_T.mat','Para_T');
save('Para_R.mat','Para_R');
save('Para_I.mat','Para_I');





